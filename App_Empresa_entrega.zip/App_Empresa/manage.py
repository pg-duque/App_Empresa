#!/usr/bin/env python
"""Punto de entrada de Django. NO hace falta modificarlo."""
import os, sys

def main():
    # Indica qué archivo de configuración usar (crm_project/settings.py)
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'crm_project.settings')
    from django.core.management import execute_from_command_line
    execute_from_command_line(sys.argv)

if __name__ == '__main__':
    main()
